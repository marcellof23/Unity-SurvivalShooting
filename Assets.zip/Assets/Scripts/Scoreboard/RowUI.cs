using UnityEngine.UI;
using UnityEngine;

public class RowUI : MonoBehaviour
{
  public Text rank;
  public Text name;
  public Text score;
}
